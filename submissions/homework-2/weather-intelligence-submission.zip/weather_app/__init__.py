"""Weather Intelligence application package."""
