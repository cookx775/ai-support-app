"""Lakebase-backed support application."""
